
## Instruction to train KMeans model 
1. Download and unzip the [spotify_million_playlist_dataset](https://www.aicrowd.com/challenges/spotify-million-playlist-dataset-challenge)
2. Place the unzipped folder inside this directory
3. Install all required python libraries with pip
   1. pandas
   2. numpy
   3. scipy
   4. matplotlib
   5. nltk
   6. wordcloud
   7. stop_words
   8. gensim
   9. pickle
   10. sklearn
   11. yellowbrick
4. Run kmeans_model_final.ipynb 
5. The run time for using 1 JSON file as raw data is about 6 hours (If you want to train the model with more data, you can change the variable number_of_json_file.)
   
## Instruction to use Recommender System
1. Install all required python libraries with pip
   1. pandas
   2. numpy 
   3. pickle
2. Make sure the kmeans_model_nlp.sav located in the same directory as recommender_system.ipynb
3. Run recommender_system.ipynb
4. Change the artist name and track name or recommended size if you want (NOTE: case sensitive)